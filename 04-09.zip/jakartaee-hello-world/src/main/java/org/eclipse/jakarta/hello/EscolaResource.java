package org.eclipse.jakarta.hello;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;

import java.util.ArrayList;
import java.util.List;

@Path("escolas")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class EscolaResource {

    //OBRIGATÓRIOS
    // api/escolas/1
    //OPCIONAIS
    // api/escolas?nome=SENAC

    private static List<Escola> escolas = new ArrayList<>();

    @GET
    public List<Escola> buscaTodos() {
        return escolas;
    }

    @POST
    public void salvar(Escola escola) {
        escolas.add(escola);
    }

    @PUT
    @Path("{id}")
    public void atualizar(@PathParam("id") int id,
                          Escola escola) {
        escolas.remove(id);
        escolas.add(id, escola);
    }

    @DELETE
    @Path("{id}")
    public void excluir(@PathParam("id") int id) {
        escolas.remove(id);
    }

}
