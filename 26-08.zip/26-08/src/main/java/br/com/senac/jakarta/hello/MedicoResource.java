package br.com.senac.jakarta.hello;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;

@Path("medicos")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class MedicoResource {

    @GET
//    @Path("buscar")
    public String meuEndpointGet2(@QueryParam("nomeMedico") String nome,
                                  @QueryParam("sobrenome") String sobrenoome) {
        return "Chamou meu endpoint! 2 " + nome;
    }

    @GET
    @Path("{nome}")
    public String parametroURL(@PathParam("nome") String nome) {
        return nome;
    }

}
